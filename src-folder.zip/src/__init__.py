"""Trading Decision-Support Tool — engine package."""

__version__ = "1.0.0"

from .amd import amd_gate, classify_amd
from .backtest import compute_metrics, print_metrics, run_backtest, simulate_trade
from .confluences import (
                          confluence_check,
                          detect_fvgs,
                          detect_ifvg_signals,
                          detect_smt,
                          update_fvg_state,
)
from .data_loader import (
                          build_continuous,
                          data_health_report,
                          load_parquet,
                          resample_ohlcv,
                          save_parquet,
)
from .manual import check
from .opening_range import (
                          build_opening_range,
                          detect_double_test,
                          detect_single_sweep,
                          find_episodes,
)
from .orchestrator import (
                          CONTRACT_SPECS,
                          Setup,
                          evaluate_session,
                          scan_range,
                          setups_to_frame,
                          veto_summary,
)
from .sessions import (
                          build_liquidity_map,
                          has_liquidity_target,
                          mark_tapped,
                          untapped_targets,
)
from .swings import (
                          classify_trend,
                          detect_bos,
                          detect_swings,
                          is_obvious_trend,
                          label_swings,
)

__all__ = [
    "classify_amd", "amd_gate",
    "run_backtest", "simulate_trade", "compute_metrics", "print_metrics",
    "detect_fvgs", "update_fvg_state", "detect_ifvg_signals", "detect_smt",
    "confluence_check",
    "build_continuous", "load_parquet", "save_parquet", "resample_ohlcv",
    "data_health_report",
    "check",
    "build_opening_range", "detect_double_test", "detect_single_sweep",
    "find_episodes",
    "evaluate_session", "scan_range", "veto_summary", "setups_to_frame",
    "Setup", "CONTRACT_SPECS",
    "build_liquidity_map", "mark_tapped", "untapped_targets",
    "has_liquidity_target",
    "detect_swings", "label_swings", "detect_bos", "classify_trend",
    "is_obvious_trend",
]
